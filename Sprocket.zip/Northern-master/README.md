# Northern Staging Repository (Version 2.0.0)
More information at https://www.nort.network/  Visit our ANN thread at  
Name: NORT

Algorithm: XEVAN

Block time: 60 seconds

Difficulty adjustment: each block (Dark Gravity Wave v3)

PoW: block 0 - 518400

POS : 518401 -7329600

POS Masternodes: 1000 NORT collateral

Darksend: TX Obfuscation

InstantX: SwiftTX

RPC port: - 61150
P2P port: - 60151

Testnet RPC port: - 51150
Testnet P2P port: - 50151

Max coin supply: 6.466.162 NORT

WHY NORTHERN?
Northern - Bringing fast and private transactions and decentralized investment into one place
NORT - the Cryptocurrency of the Northern networks runs on a Xevan blockchain, a cutting edge algorithm used by few coins. This means we are on the cutting edge of blockchain technology offering something new and not just another fork. NORT is seen as a store of value with our masternodes backing this. There is such a limited supply, this means like other commodities, NORT will rise in value. 
Xevan is ASIC resistant, meaning we are able to provide a truly decentralized network. Northern Networks aims to bring a fair system to miners and investors alike.  We will be rolling out our POS masternode network from launch with a fair masternode distrobution system. Not auctions like some projects do, But open to all with the base staking amount being 1000 NORT. 
We believe this system is the best when it comes to the security and integrity of the network as we create an extensive network of around 1000 nodes, securing the blockchain and confirming transactions quickly and efficient. As POW burns lots of energy yearly we hope to move to a completely POS network that is green and efficient. 
