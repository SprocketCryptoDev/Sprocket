Sample configuration files for:

SystemD: northernd.service
Upstart: northernd.conf
OpenRC:  northernd.openrc
         northernd.openrcconf
CentOS:  northernd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
